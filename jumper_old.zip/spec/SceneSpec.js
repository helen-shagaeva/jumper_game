describe("Scene", function () {
    var jumper;

    beforeEach(function () {
        jumper = new Jumper();

    });

    it("should be moving to OY automatically", function () {

    });
});